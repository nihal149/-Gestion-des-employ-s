package ma.projet.test;

import ma.projet.beans.Developpeur;
import ma.projet.beans.Manager;
import ma.projet.beans.DirecteurGeneral;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Entreprise {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/gestion"; // Remplacez par votre URL de base de données
    private static final String USER = "root"; // Remplacez par votre utilisateur
    private static final String PASSWORD = ""; // Remplacez par votre mot de passe

    public static void main(String[] args) {
        // Créer les employés
        DirecteurGeneral directeurGeneral = new DirecteurGeneral(1, "Émilie", "Lefèvre", 6000);
        Manager manager = new Manager(1, "Claire", "Bernard", 4000);
        Developpeur dev1 = new Developpeur(1, "Alice", "Dupont", 3000);
        Developpeur dev2 = new Developpeur(2, "Bob", "Martin", 2800);
        Developpeur dev3 = new Developpeur(3, "David", "Durand", 3200);

        // Insertion des données dans la base de données
        save(directeurGeneral);
        save(manager);
        save(dev1);
        save(dev2);
        save(dev3);

        // Créer la fenêtre pour afficher les résultats
        SwingUtilities.invokeLater(() -> createAndShowGUI(directeurGeneral, manager, dev1, dev2, dev3));
    }

    private static void createAndShowGUI(DirecteurGeneral dg, Manager mgr, Developpeur... devs) {
        JFrame frame = new JFrame("Informations des employés");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);

        // Création de l'arbre
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Entreprise");
        DefaultMutableTreeNode directeurNode = new DefaultMutableTreeNode(dg.getNom() + " " + dg.getPrenom());
        DefaultMutableTreeNode managerNode = new DefaultMutableTreeNode(mgr.getNom() + " " + mgr.getPrenom());

        // Ajout des développeurs au manager
        DefaultMutableTreeNode devNode1 = new DefaultMutableTreeNode(devs[0].getNom() + " " + devs[0].getPrenom());
        DefaultMutableTreeNode devNode2 = new DefaultMutableTreeNode(devs[1].getNom() + " " + devs[1].getPrenom());
        DefaultMutableTreeNode devNode3 = new DefaultMutableTreeNode(devs[2].getNom() + " " + devs[2].getPrenom());

        // Construire la hiérarchie
        root.add(directeurNode);
        directeurNode.add(managerNode);
        managerNode.add(devNode1);
        managerNode.add(devNode2);
        managerNode.add(devNode3);

        // Créer le JTree
        JTree tree = new JTree(root);
        JScrollPane scrollPane = new JScrollPane(tree);
        
        frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    private static void save(Object employee) {
        if (employee instanceof DirecteurGeneral) {
            DirecteurGeneral dg = (DirecteurGeneral) employee;
            saveDirecteurGeneral(dg);
        } else if (employee instanceof Manager) {
            Manager mgr = (Manager) employee;
            saveManager(mgr);
        } else if (employee instanceof Developpeur) {
            Developpeur dev = (Developpeur) employee;
            saveDeveloppeur(dev);
        }
    }

    private static void saveDirecteurGeneral(DirecteurGeneral directeurGeneral) {
        String query = "INSERT INTO Directeur_General (nom, prenom, salaire) VALUES (?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(query)) {

            pstmt.setString(1, directeurGeneral.getNom());
            pstmt.setString(2, directeurGeneral.getPrenom());
            pstmt.setDouble(3, directeurGeneral.getSalaire());
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void saveManager(Manager manager) {
        String query = "INSERT INTO Manager (nom, prenom, salaire, id_directeur) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(query)) {

            pstmt.setString(1, manager.getNom());
            pstmt.setString(2, manager.getPrenom());
            pstmt.setDouble(3, manager.getSalaire());
            pstmt.setInt(4, 1); // Remplacez par l'ID du directeur général approprié
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void saveDeveloppeur(Developpeur developpeur) {
        String query = "INSERT INTO Developpeur (nom, prenom, salaire, id_manager) VALUES (?, ?, ?, ?)";
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pstmt = connection.prepareStatement(query)) {

            pstmt.setString(1, developpeur.getNom());
            pstmt.setString(2, developpeur.getPrenom());
            pstmt.setDouble(3, developpeur.getSalaire());
            pstmt.setInt(4, 1); // Remplacez par l'ID du manager approprié
            pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}